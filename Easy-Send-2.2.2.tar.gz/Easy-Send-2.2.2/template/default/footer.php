<?php /*
By Ivan Hanloth
本文件为易传尾部模板文件
2022/4/3
*/
?>

<footer>
    <?php echo $footer;  ?>
</footer>
  </body>
</html>