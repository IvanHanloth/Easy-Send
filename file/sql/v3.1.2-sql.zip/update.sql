ALTER TABLE `room` CHANGE `send` `send` TEXT NOT NULL, CHANGE `receive` `receive` TEXT NOT NULL;
TRUNCATE room;
UPDATE `setting` SET `content`='312' WHERE `name`='version_num';
UPDATE `setting` SET `content`='v3.1.2' WHERE `name`='version';