UPDATE `setting` SET `content`='331' WHERE `name`='version_num';
UPDATE `setting` SET `content`='v3.3.1' WHERE `name`='version';
