UPDATE `setting` SET `content` = 'v3.4.1' WHERE `name` = 'version';
UPDATE `setting` SET `content` = '341' WHERE `name` = 'version_num';
