UPDATE `setting` SET `content` = 'v3.4.3' WHERE `name` = 'version';
UPDATE `setting` SET `content` = '343' WHERE `name` = 'version_num';
