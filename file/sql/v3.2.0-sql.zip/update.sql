INSERT INTO `setting` (`id`, `name`, `content`, `description`) VALUES (NULL, 'if_scan', 'on', '是否开启扫码功能');
UPDATE `setting` SET `content`='320' WHERE `name`='version_num';
UPDATE `setting` SET `content`='v3.2.0' WHERE `name`='version';
ALTER TABLE `data` ADD `uid` INT NOT NULL DEFAULT '0' AFTER `times`;
ALTER TABLE `room` ADD `senduid` INT NOT NULL DEFAULT '0' AFTER `receive`, ADD `recevieuid` INT NOT NULL DEFAULT '0' AFTER `senduid`;
CREATE TABLE `user` ( `uid` INT NOT NULL AUTO_INCREMENT , `account` TEXT NOT NULL , `password` TEXT NOT NULL , `usertoken` TEXT NOT NULL , `mail` TEXT NOT NULL , PRIMARY KEY (`uid`)) ENGINE = InnoDB;