UPDATE `setting` SET `content` = 'v3.4.2' WHERE `name` = 'version';
UPDATE `setting` SET `content` = '342' WHERE `name` = 'version_num';
