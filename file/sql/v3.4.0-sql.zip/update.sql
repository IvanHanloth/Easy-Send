INSERT INTO `setting` (`id`, `name`, `content`, `description`) VALUES (NULL, 'whole_upload', 'on', '是否启用整页上传');
DELETE FROM `setting` WHERE `name` = 'qrcode' AND EXISTS (SELECT 1 FROM `setting` WHERE `name` = 'qrcode');
UPDATE `setting` SET `content` = 'v3.4.0' WHERE `name` = 'version';
UPDATE `setting` SET `content` = '340' WHERE `name` = 'version_num';
