ALTER TABLE `room` CHANGE `send` `send` TEXT NOT NULL, CHANGE `receive` `receive` TEXT NOT NULL;
TRUNCATE room;
UPDATE `setting` SET `content`='313' WHERE `name`='version_num';
UPDATE `setting` SET `content`='v3.1.3' WHERE `name`='version';