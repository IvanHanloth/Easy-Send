UPDATE `setting` SET `content`='310' WHERE `name`='version_num' ;
UPDATE `setting` SET `content`='v3.1.0' WHERE `name`='version' ;
INSERT INTO `setting` (`name`, `content`) VALUES
('varify_type','mix'),
('varify_num','4')