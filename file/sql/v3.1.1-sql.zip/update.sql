UPDATE `setting` SET `content`='311'  WHERE `name`='version_num';
UPDATE `setting` SET `content`='v3.1.1'  WHERE `name`='version';