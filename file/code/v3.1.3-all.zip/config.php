
<?php
/*数据库配置*/
$dbconfig=array(
    "host" => "localhost", //数据库服务器
    "port" => 3306, //数据库端口
    "account" => "", //数据库用户名
    "password" => "", //数据库密码
    "name" => "", //数据库名
);
?>
