<?php
session_start();
header('Content-Type:application/json; charset=utf-8');
$_SESSION["admin"]=""
?>
{"code":200}