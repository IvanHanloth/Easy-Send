<?php
      /*
By Ivan Hanloth
Easy-Send
Github:https://github.com/IvanHanloth/Easy-Send
Gitee:https://gitee.com/IvanHanloth/Easy-Send
2022/10/16
*/tem_require_head()?>
  <body>
      <style>
          html,body{ margin:0; height:100%;  }
      </style>
      <?php tem_user_default()?>
        <footer>
    <?php tem_require_footer()?>     
    </footer>
      </body>
      </html>