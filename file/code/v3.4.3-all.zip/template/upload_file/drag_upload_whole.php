<link rel="stylesheet" href="/public/template/upload_file/css/drag_upload_whole.css" />
<div class="whole-page-drag">
    <div class="whole-dragbackground" id="whole-zone">
        <div class="whole-dragbox">
            <div>
                <i class="layui-icon layui-anim layui-anim-upbit" data-anim="layui-anim-down" style="font-size:40px;"></i>
                <p style="font-size:30px;">将文本或文件拖拽到此处上传</p>
                <br>
                <button type="button" class="layui-btn layui-btn-lg layui-btn-primary layui-btn-radius" style="color:#fff" onclick="document.getElementById('whole-zone').style.display = 'none'">取消</button>

            </div>
        </div>
    </div>
</div>
<script src="/public/template/upload_file/js/drag_upload_whole.js"></script>