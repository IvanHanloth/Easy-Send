UPDATE `setting` SET `content`='301' WHERE `name`='version_num' ;
UPDATE `setting` SET `content`='v3.0.1' WHERE `name`='version' ;