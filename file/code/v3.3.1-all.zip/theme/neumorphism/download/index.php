<?php
      /*
By Ivan Hanloth
Easy-Send
Github:https://github.com/IvanHanloth/Easy-Send
Gitee:https://gitee.com/IvanHanloth/Easy-Send
2022/10/16
*/tem_require_head()?>
  <body>
      <link rel="stylesheet" type="text/css" href="/theme/neumorphism/static/css/index.css">
        <div class="main window"></div>
        <div class="logo">
            <img src="<?php echo $logo?>" height="50px">
        </div>
            <div class="main"><?php tem_download_big_showpercent()?>
            </div>
        <footer>
    <?php tem_require_footer()?>
</footer>
  </body>
</html>
