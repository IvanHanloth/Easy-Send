<?php
echo $footer;
?>