<?php
session_start();
$_SESSION["admin"]=""
?>
{"code":200}